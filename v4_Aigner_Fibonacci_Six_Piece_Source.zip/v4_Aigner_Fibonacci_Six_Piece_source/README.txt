Aigner's Three Monotonicities from Fibonacci Matrices and Six Snake Pieces
VERSION 4 - 11 November 2026
Elleard Felix Webster Heffern

This standalone edition is synchronized with the Aigner arguments in Section 5
of Meridians on the Markov Surface, version 21 (9 November 2026):
https://doi.org/10.5281/zenodo.24096109

The normalization argument, all three ordering proofs, and the two vector
figure files match that manuscript. The mathematical arguments and figure
files were already present in standalone v3; this edition aligns presentation,
attribution and the fixed-sum caption, and makes the provenance explicit.
This is an update of an existing proof, not a new mathematical result.

BUILD
  latexmk -pdf -interaction=nonstopmode -halt-on-error -jobname=v4_Aigner_Fibonacci_Six_Piece_Proof -outdir=build main.tex

VALIDATION
  python3 checks/check_fibonacci_normalization.py
  python3 checks/check_orderings.py
The checks are finite validation, not a replacement for the written proof.
checks/historical_v3/ preserves the earlier reports. Current reports and the
manuscript-alignment check accompany this edition.

LICENSE
Creative Commons Attribution 4.0 International, retaining the original
Zenodo record's license: https://creativecommons.org/licenses/by/4.0/
Earlier cited constructions and results retain their attribution.

SHA256SUMS.json covers packaged files other than itself. Build intermediates
are excluded. The standalone figures are numbered 1 and 2.
