#!/usr/bin/env python3
"""Exact finite checks of the Fibonacci-block proof; not a unicity survey."""
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
from itertools import product
from math import gcd
from pathlib import Path
import json
import time

ROOT = Path(__file__).resolve().parents[1]
IDENTITY = (1, 0, 0, 1)

@lru_cache(None)
def fib(n):
    if n < 0:
        return (-1 if (-n) % 2 == 0 else 1) * fib(-n)
    return n if n < 2 else fib(n-1)+fib(n-2)

@lru_cache(None)
def block(t):
    return (fib(2*t+3), fib(2*t+1), fib(2*t+1), fib(2*t-1))

def mul(a, b):
    return (a[0]*b[0]+a[1]*b[2], a[0]*b[1]+a[1]*b[3],
            a[2]*b[0]+a[3]*b[2], a[2]*b[1]+a[3]*b[3])

def sub(a, b):
    return tuple(x-y for x, y in zip(a, b))

@lru_cache(None)
def matrix(ts):
    out = IDENTITY
    for t in ts:
        out = mul(out, block(t))
    return out

def canonical(p, q):
    return tuple((j*q+p-1)//p-((j-1)*q+p-1)//p-(j == 1)
                 for j in range(1, p+1))

def compositions(s, p):
    if p == 1:
        yield (s,)
    else:
        for t in range(s+1):
            for tail in compositions(s-t, p-1):
                yield (t,)+tail

def discrepancies(ts, p, q):
    total = 1
    out = [0]
    for j, t in enumerate(ts, 1):
        total += t
        out.append(q*j-p*total)
    assert out[-1] == 0
    return out

def next_step(ts, p, q):
    ds = discrepancies(ts, p, q)
    if max(ds) > 0:
        j = max(range(1, p), key=lambda j: (ds[j], j))
        direction, phase = 1, 'positive'
    elif min(ds) < -p:
        j = min(range(1, p), key=lambda j: (ds[j], j))
        direction, phase = -1, 'negative'
    else:
        assert ts == canonical(p, q)
        return None
    out = list(ts)
    out[j-1] += direction
    out[j] -= direction
    out = tuple(out)
    assert min(out) >= 0 and sum(out) == q-1
    after = discrepancies(out, p, q)
    assert all(after[i] == ds[i] for i in range(p+1) if i != j)
    assert after[j] == ds[j]-direction*p
    if phase == 'negative':
        assert max(after) <= 0
    assert matrix(out)[0] < matrix(ts)[0], (ts, out, p, q)
    return out, phase, abs(ts[j-1]-ts[j]) == 1, j

def independent_matching_count(ts):
    # Build the actual square-grid snake and count perfect matchings of its
    # vertex/edge graph. This does not use block products or continuants.
    word = 'a'*(ts[0]+1)+'b'+''.join('a'*t+'b' for t in ts[1:])
    cells = [(0, 0)]
    x = y = 0
    for letter in word[1:-1]:
        for _ in range(2):
            if letter == 'a':
                x += 1
            else:
                y += 1
            cells.append((x, y))
    edges = set()
    for x, y in cells:
        vs = [(x, y), (x+1, y), (x+1, y+1), (x, y+1)]
        for i in range(4):
            edges.add(tuple(sorted((vs[i], vs[(i+1) % 4]))))
    vertices = sorted({v for e in edges for v in e})
    vi = {v:i for i,v in enumerate(vertices)}
    adjacency = [0]*len(vertices)
    for a, b in edges:
        adjacency[vi[a]] |= 1 << vi[b]
        adjacency[vi[b]] |= 1 << vi[a]

    @lru_cache(None)
    def count(mask):
        if not mask:
            return 1
        active = [i for i in range(len(vertices)) if mask >> i & 1]
        i = min(active, key=lambda i: (adjacency[i] & mask).bit_count())
        neighbors = adjacency[i] & mask
        total = 0
        while neighbors:
            bit = neighbors & -neighbors
            neighbors -= bit
            total += count(mask ^ (1 << i) ^ bit)
        return total
    return count((1 << len(vertices))-1)

def main():
    started = datetime.now(timezone.utc).isoformat()
    clock = time.monotonic()
    report = {'scope':'Exact finite validation of the written normalization proof; not a proof by enumeration or a new Markov unicity run.',
              'started_utc':started}
    for k in range(1, 101):
        assert fib(2*k-1)*fib(2*k+3)-fib(2*k+1)**2 == 1
    for k in range(2, 102):
        assert sub(mul(block(k), block(k-2)), mul(block(k-1), block(k-1))) == (2,6,0,2)
        assert sub(mul(block(k-2), block(k)), mul(block(k-1), block(k-1))) == (2,0,6,2)
    report['odd_index_and_AC_BB_cases'] = {'odd_identity':100, 'AC_and_CA':100}
    shifts = 0
    for r in range(1, 41):
        for s in range(41):
            assert fib(2*r+1)*fib(2*s+1)-fib(2*r-1)*fib(2*s+3) == fib(2*(r-s)-2)
            expected = tuple(2*fib(n) for n in (2*(r-s)-2,2*(r-s),2*(r-s)-4,2*(r-s)-2))
            assert sub(mul(block(r),block(s)),mul(block(r-1),block(s+1))) == expected
            shifts += 1
    report['general_scalar_and_matrix_shift_cases'] = shifts

    lists = [u for n in range(5) for u in product(range(4), repeat=n)]
    comparisons = 0
    for u in lists:
        for v in lists:
            a, b = matrix(u), matrix(v)
            actual = a[2]*b[0]-b[2]*a[0]
            i = 0
            while i < min(len(u),len(v)) and u[i] == v[i]:
                i += 1
            if i == min(len(u),len(v)):
                expected = len(u)-len(v)
            else:
                expected = v[i]-u[i]
            assert (actual > 0)-(actual < 0) == (expected > 0)-(expected < 0)
            comparisons += 1
    report['outward_ratio_comparisons'] = comparisons

    states = steps = trajectories = graph_checks = 0
    case_counts = Counter()
    longest = 0
    for n in range(2, 19):
        for p in range(1, n):
            q = n-p
            if gcd(p,q) != 1:
                continue
            target = canonical(p,q)
            target_value = matrix(target)[0]
            for ts in compositions(q-1, p):
                states += 1
                assert matrix(ts)[0] >= target_value
                if n <= 9:
                    assert independent_matching_count(ts) == matrix(ts)[0]
                    graph_checks += 1
                current = ts
                length = 0
                while (step := next_step(current,p,q)) is not None:
                    current, phase, gap_one, j = step
                    steps += 1
                    length += 1
                    case_counts[phase+('_gap_one' if gap_one else '_gap_at_least_two')] += 1
                    if j == 1 or j == p-1:
                        case_counts['end_pair'] += 1
                assert current == target
                longest = max(longest,length)
                trajectories += 1
    report['exhaustive_normalization'] = {
        'range':'All coprime positive p,q with p+q <= 18; all nonnegative block-index lists of length p and sum q-1.',
        'initial_lists':states,'completed_trajectories':trajectories,
        'strictly_decreasing_steps':steps,'longest_trajectory':longest,
        'step_cases':dict(case_counts)}
    report['independent_actual_graph_matching_counts'] = {'p_plus_q_max':9,'cases':graph_checks}
    assert matrix((3,3))[0] == 1325
    assert matrix((2,2))[0] == 194
    assert mul(block(3),block(1))[0] == 196
    assert matrix(canonical(2,9))[0] == 9077
    assert matrix(canonical(3,8))[0] == 7561
    report['displayed_examples'] = 'passed'
    report['status'] = 'passed'
    report['elapsed_seconds'] = round(time.monotonic()-clock,3)
    report['completed_utc'] = datetime.now(timezone.utc).isoformat()
    (ROOT/'checks/fibonacci_normalization_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__ == '__main__':
    main()
