"""Exact checks of local graphs, surgeries and Farey-indexed inequalities."""
from collections import defaultdict
from datetime import datetime, timezone
from functools import lru_cache
from itertools import product
from math import gcd
from pathlib import Path
import json
import time

from check_fibonacci_normalization import canonical, matrix, independent_matching_count

ROOT=Path(__file__).resolve().parents[1]

def graph_count(cells, removed=()):
    removed=set(removed)
    edges=set()
    vertices=set()
    for x,y in cells:
        corners=[(x,y),(x+1,y),(x+1,y+1),(x,y+1)]
        vertices.update(corners)
        edges.update(tuple(sorted((corners[i],corners[(i+1)%4]))) for i in range(4))
    vertices=sorted(vertices-removed)
    positions={v:i for i,v in enumerate(vertices)}
    neighbors=[0]*len(vertices)
    for a,b in edges:
        if a in positions and b in positions:
            neighbors[positions[a]]|=1<<positions[b]
            neighbors[positions[b]]|=1<<positions[a]
    @lru_cache(None)
    def count(mask):
        if not mask:return 1
        i=min((i for i in range(len(vertices)) if mask>>i&1),key=lambda i:(neighbors[i]&mask).bit_count())
        options=neighbors[i]&mask
        total=0
        while options:
            bit=options&-options;options-=bit
            total+=count(mask^(1<<i)^bit)
        return total
    return count((1<<len(vertices))-1)

def boundary_counts(cells,left,right):
    result=[]
    for a,b in [(0,0),(0,1),(1,0),(1,1)]:
        if a and b and set(left)&set(right):result.append(0)
        else:result.append(graph_count(cells,(left if a else [])+(right if b else [])))
    return tuple(result)

def indices(word):
    assert word[0]=='a' and word[-1]=='b'
    runs=[len(s) for s in word[:-1].split('b')]
    runs[0]-=1
    return tuple(runs)

def word(p,q):
    ts=canonical(p,q)
    return 'a'*(ts[0]+1)+'b'+''.join('a'*t+'b' for t in ts[1:])

def surgery(w):
    z=w[1:-1]
    j=max(i for i in range(len(z)-1) if z[i]==z[i+1])
    assert z[j:j+2]=='aa'
    z=z[:j+1]+''.join('b' if c=='a' else 'a' for c in z[j+1:])
    return 'a'+z+'b'

def main():
    start=time.monotonic()
    report={'started_utc':datetime.now(timezone.utc).isoformat(),
            'scope':'Finite validation of the written Aigner arguments; no unicity or production enumeration.'}
    cells=[(0,0),(1,0),(2,0)]
    left=[(0,0),(0,1)];right=[(3,0),(3,1)]
    bottom_left=[(0,0),(1,0)];top_right=[(2,1),(3,1)]
    pieces={
      '2':boundary_counts(cells,left,right),
      '3':boundary_counts(cells,left,top_right),
      '4':boundary_counts(cells,bottom_left,right),
      '5':boundary_counts(cells,bottom_left,top_right),
      '1':boundary_counts([(0,0),(0,1),(0,2)],[(0,0),(0,1)],[(1,2),(1,3)]),
      '6i':boundary_counts([(0,0)],[(0,0),(0,1)],[(1,0),(1,1)])}
    assert pieces=={'1':(5,2,2,1),'2':(5,3,3,2),'3':(5,2,3,1),
                    '4':(5,3,2,1),'5':(5,2,2,1),'6i':(2,1,1,1)},pieces
    report['independent_six_piece_boundary_counts']=pieces
    before={};after={}
    for incoming,outgoing in product('ab',repeat=2):
        left=[(0,0),(0,1)] if incoming=='a' else [(0,0),(1,0)]
        right=[(1,0),(1,1)] if outgoing=='a' else [(0,1),(1,1)]
        right_new=[(1,2),(1,3)] if outgoing=='a' else [(0,3),(1,3)]
        key=incoming+outgoing
        before[key]=boundary_counts([(0,0)],left,right)
        after[key]=boundary_counts([(0,0),(0,1),(0,2)],left,right_new)
        assert all(b>=a for a,b in zip(before[key],after[key]))
        assert after[key][0]>before[key][0]
    assert after=={'aa':(5,2,2,1),'ab':(5,3,2,1),'ba':(5,2,3,1),'bb':(5,3,3,2)}
    report['fixed_denominator_boundary_counts']={'before':before,'after':after}

    graph_cases=0
    for n in range(2,12):
        for letters in product('ab',repeat=n-2):
            ts=indices('a'+''.join(letters)+'b')
            assert matrix(ts)[0]==independent_matching_count(ts)
            graph_cases+=1
    report['actual_graph_vs_fibonacci_product_cases']=graph_cases

    # Generate standard Farey-labelled Markov maxima by Vieta recursion,
    # independently of the snake/matrix count.
    values={}
    def visit(lp,lq,lm,rp,rq,rm,opposite):
        p,q=lp+rp,lq+rq
        if p+q>45:return
        m=3*lm*rm-opposite
        assert m==matrix(canonical(p,q))[0]
        values[p,q]=m
        visit(lp,lq,lm,p,q,m,rm)
        visit(p,q,m,rp,rq,rm,lm)
    visit(0,1,1,1,1,2,1)
    report['independent_farey_vieta_values']=len(values)
    counts={}
    for kind in ['numerator','denominator','sum']:
        groups=defaultdict(list)
        for (p,q),m in values.items():
            groups[p if kind=='numerator' else q if kind=='denominator' else p+q].append((q if kind=='numerator' else p,m))
        total=0
        for group in groups.values():
            ordered=sorted(group)
            for i,(_,a) in enumerate(ordered):
                for _,b in ordered[i+1:]:
                    assert (a>b) if kind=='sum' else (a<b)
                    total+=1
        counts[kind]=total
    report['all_pair_ordering_checks_height_45']=counts

    operations=endpoints=0
    for p,q in values:
        w=word(p,q)
        original=matrix(indices(w))[0]
        previous=original
        for step in range(1,q-p):
            w=surgery(w)
            current=matrix(indices(w))[0]
            assert current<previous
            previous=current
            operations+=1
            if step%2==0:
                i=step//2
                assert w.count('a')==q-i and w.count('b')==p+i
                if gcd(p+i,q-i)==1:
                    assert matrix(canonical(p+i,q-i))[0]<=current<original
                endpoints+=1
    report['strict_fixed_sum_surgery_steps']=operations
    report['two_step_endpoint_checks']=endpoints
    w=word(2,9)
    actual=[matrix(indices(w))[0]]
    for _ in range(2):w=surgery(w);actual.append(matrix(indices(w))[0])
    assert actual==[9077,8263,7661]
    report['fixed_sum_example']=actual+[matrix(canonical(3,8))[0]]
    report['status']='passed'
    report['elapsed_seconds']=round(time.monotonic()-start,3)
    report['completed_utc']=datetime.now(timezone.utc).isoformat()
    (ROOT/'checks/ordering_checks.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
